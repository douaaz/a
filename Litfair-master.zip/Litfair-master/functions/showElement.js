export const showElement = (id) => {
  document.getElementById(id).classList.remove("invisible");
};
