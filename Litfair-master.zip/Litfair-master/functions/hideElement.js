export const hideElement = (id) => {
  document.getElementById(id).classList.add("invisible");
};
