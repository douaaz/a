export const ActivateBar = (id) => {
  const el = document.getElementById(id);
  el.classList.add("barActive");
};
